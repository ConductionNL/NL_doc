# Running your own instance of NLdoc

This repository includes examples how to run on NLdoc on your own Kubernetes cluster. Concrete examples can be found at [kubernetes/](kubernetes/) and [docker-compose/](docker-compose/).
