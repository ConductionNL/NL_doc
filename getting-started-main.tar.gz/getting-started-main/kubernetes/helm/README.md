# Running NLdoc on Helm

## Prerequisites

This guide assumes you have dependencies, such as PostgreSQL, RabbitMQ and a S3-compatible API pre-installed.

### PostgreSQL

PostgreSQL can likely be rented via your own hosting provider. You could also set it up on Kubernetes. We suggest setting up [using the PostgreSQL operator CloudNativePG.](https://cloudnative-pg.io/)

### RabbitMQ

RabbitMQ can likely be rented via your own hosting provider. You could also set it up on Kubernetes. We suggest setting up [using the official RabbitMQ operator.](https://www.rabbitmq.com/kubernetes/operator/operator-overview)

### S3

S3 storage can likely be rented via your own hosting provider. You could also set it up on Kubernetes. There are a few ways you could setup S3.

We suggest using [Minio](https://min.io/). [You can find documentation about setting it up on their website.](https://docs.min.io/community/minio-object-store/operations/deployments/installation.html)

Other S3 compatible API's, such as [Ceph](https://ceph.com/) and [SeaweedFS](https://seaweedfs.com/) are untested but expected to work.

## Charts

NLdoc exists of multiple Helm charts.

| Chart        | Function                                                                | URL                                                              |
| ------------ | ----------------------------------------------------------------------- | ---------------------------------------------------------------- |
| `kimi`       | Workers for document conversion and accessibility validation.                       | https://gitlab.com/api/v4/projects/68736728/packages/helm/stable |
| `editor-app` | Front-end for editing, validating and converting documents.             | https://gitlab.com/api/v4/projects/68643351/packages/helm/stable |
| `api`        | API for converting and validating documents, also used by `editor-app`. | https://gitlab.com/api/v4/projects/68640094/packages/helm/stable |

## Before deploying

Currently, specific buckets need to be created manually. In the future we will support upsertion of buckets when starting the application.

Please manually create the following buckets: `files`, `nldoc-conversion-api-uploads`, `kimi-debug`, `pages`, `output`, `staticassets`, `station-source-object-records`.

## Deploying

You could deploy by a tool like [Helmfile](https://helmfile.readthedocs.io/) or using [Helm.](https://helm.sh/)

Please note that in both cases you will need to configure credentials, namespaces and RabbitMQ, PostgreSQL and S3.


    # Using Helmfile sync
    $ helmfile sync -f helmfile.yaml

    # Or Helmfile apply
    $ helmfile apply -f helmfile.yaml

    # Using Helm
    $ helm repo add kimi "https://gitlab.com/api/v4/projects/68736728/packages/helm/stable"
    $ helm repo add editor-app "https://gitlab.com/api/v4/projects/68643351/packages/helm/stable"
    $ helm repo add nldoc-api "https://gitlab.com/api/v4/projects/68640094/packages/helm/stable"
    $ helm repo update

    $ helm upgrade --install editor-app editor-app/editor-app \
        --values ./values/editor-app.yaml

    $ helm upgrade --install api nldoc-api/api \
        --values ./values/api.yaml \
        --values ./values/amqp-client.yaml \
        --values ./values/s3-client.yaml

    $ helm upgrade --install kimi kimi/kimi \
        --values ./values/amqp-client.yaml \
        --values ./values/s3-client.yaml \
        --values ./values/postgresql-client.yaml \
        --values ./values/kimi.yaml
