# Running NLdoc with Docker Compose

## Prerequisites

This guide uses Docker Compose to run NLdoc with all its dependencies (PostgreSQL, RabbitMQ, and MinIO S3-compatible storage) in containers.

### Requirements

- [Docker](https://docs.docker.com/get-docker/) (version 20.10 or higher)
- [Docker Compose](https://docs.docker.com/compose/install/) (version 2.0 or higher)

## Configuration

The stack includes the following services:

| Service      | Function                                                                | Default Port |
| ------------ | ----------------------------------------------------------------------- | ------------ |
| `editor-app` | Front-end for editing, validating and converting documents.            | 8080         |
| `api`        | API for converting and validating documents, also used by `editor-app`.| 4000         |
| `kimi`       | Workers and stations for document conversion and accessibility validation. | -            |
| `postgresql` | PostgreSQL database for storing application data.                       | 5432         |
| `rabbitmq`   | RabbitMQ message queue for coordinating document processing.            | 5672, 15672  |
| `minio`      | MinIO S3-compatible object storage for document files.                  | 9000, 9001   |

### Environment Variables

Port mappings can be customized via the `.env` file. Create or edit `.env` in the same directory as `docker-compose.yml`:

```env
UI_PORT=8080
API_PORT=4000
POSTGRES_PORT=5432
AMQP_PORT=5672
RABBITMQ_MGMT_PORT=15672
S3_PORT=9000
MINIO_CONSOLE_PORT=9001
```

Credentials can also be found or customized in this .env file. This goes for Minio, RabbitMQ and PostgreSQL, but also for access to the `/beta` url of the nldoc-editor;

```env
BASIC_AUTH_USER=username
BASIC_AUTH_PASSWORD=password
```

## Starting the Stack

Start all services:

```bash
docker-compose up -d
```

Check service health:

```bash
docker-compose ps
```

View logs:

```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f editor-app
```

## Accessing the Application

Once all services are healthy:

- **NLdoc Editor UI**: http://localhost:8080/beta - (username: `username` / password: `password`)
- **API**: http://localhost:4000
- **RabbitMQ Management UI**: http://localhost:15672 (username: `user` / password: `password`)
- **MinIO Console**: http://localhost:9001 (username: `access-key` / password: `secret-key`)

## Storage Buckets

The following S3 buckets are automatically created on startup:

- `files`
- `nldoc-conversion-api-uploads`
- `worker-data`
- `pages`
- `output`
- `staticassets`
- `station-source-object-records`

## Stopping the Stack

Stop all services (keeps data):

```bash
docker-compose down
```

Stop and remove all data:

```bash
docker-compose down -v
```

## Troubleshooting

### Services not starting

Check service logs:
```bash
docker-compose logs <service-name>
```

### Port conflicts

If ports are already in use, modify the `.env` file to use different ports.

### Disk space issues

Clean up unused Docker resources:
```bash
docker system prune -a --volumes
```

## Scaling Workers

To scale specific workers for better performance:

```bash
docker-compose up -d --scale kimi-worker-page-interpreted-content-ocr=5
docker-compose up -d --scale kimi-worker-page-regions-yolo=5
```
